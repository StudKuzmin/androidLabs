package com.example.lab7.modules

import com.example.lab7.data.ImageData

interface CellClickListener {
    fun onCellClickListener(data: ImageData)
}