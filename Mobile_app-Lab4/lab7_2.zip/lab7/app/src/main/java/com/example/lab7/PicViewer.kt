package com.example.lab7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PicViewer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pic_viewer)
    }
}