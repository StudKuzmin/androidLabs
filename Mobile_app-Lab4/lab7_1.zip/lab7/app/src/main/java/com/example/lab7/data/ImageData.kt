package com.example.lab7.data

data class ImageData(val imageUrl: String)