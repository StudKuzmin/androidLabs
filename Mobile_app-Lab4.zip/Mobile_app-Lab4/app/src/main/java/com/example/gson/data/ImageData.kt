package com.example.gson.data

data class ImageData(val imageUrl: String)