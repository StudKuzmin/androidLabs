package com.example.gson.modules

import com.example.gson.data.ImageData

interface CellClickListener {
    fun onCellClickListener(data: ImageData)
}