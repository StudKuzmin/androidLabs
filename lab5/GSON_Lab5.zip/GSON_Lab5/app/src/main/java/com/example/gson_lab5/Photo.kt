package com.example.gson_lab5

class Photo {
    var id: String = ""
    var owner: String = ""
    var secret: String = ""
    var server: String = ""
    var title: String = ""
    var farm: Int = 0
    var ispublic: Int = 0
    var isfriend: Int = 0
    var isfamily: Int = 0
}