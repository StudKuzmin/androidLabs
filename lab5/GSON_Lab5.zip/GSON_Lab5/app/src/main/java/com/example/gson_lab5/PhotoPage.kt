package com.example.gson_lab5

class PhotoPage {
    var page: Int = 0
    var pages: Int = 0
    var perpage: Int = 0
    var total: Int = 0
    var photo: List<Photo> = listOf()
}