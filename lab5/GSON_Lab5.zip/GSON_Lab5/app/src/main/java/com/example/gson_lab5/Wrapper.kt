package com.example.gson_lab5

class Wrapper{
    var photos: PhotoPage? = null;
}