package com.example.mydialer_lab6

class Contact(var name: String, var phone: String, var type: String) {}